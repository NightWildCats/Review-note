DROP TABLE IF EXISTS `region`;

CREATE TABLE `region` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(30) default NULL,
  `parent_id` int(11) default NULL,
  `lft` int(10) unsigned default NULL,
  `rgt` int(10) unsigned default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

insert  into `region`(`id`,`name`,`parent_id`,`lft`,`rgt`) values (1,'中国',0,1,20),(2,'北京',1,2,5),(3,'北京市',2,3,4),(4,'上海',1,6,9),(5,'上海市',4,7,8),(6,'浙江',1,10,19),(7,'金华',6,15,16),(8,'温州',6,17,18),(9,'杭州',6,11,12),(10,'宁波',6,13,14);

--------------------------------
SELECT node.name, node.lft, node.rgt
FROM region AS node, region AS parent
WHERE node.lft >= parent.lft and node.rgt <= parent.rgt AND parent.id = 1
ORDER BY node.lft;

SELECT CONCAT(REPEAT('  ', COUNT(parent.id)-1), node.name) AS name, node.id,node.lft,node.rgt, COUNT(parent.id)
FROM region AS node, region AS parent
where  node.lft BETWEEN parent.lft AND parent.rgt
group by node.id
ORDER BY node.lft;

select  node.name as name from region as node where lft>1 and rgt<20
select parent.name, parent.id from region as node, region as parent where node.lft BETWEEN parent.lft and parent.rgt and node.id=5;

--------------------------------

/* 调用 call region_pro(1,1,@k);select @k;*/
DELIMITER $$

DROP PROCEDURE IF EXISTS `tyfw`.`region_pro`$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `region_pro`(in _lft int,in fid int,out m int)
BEGIN
	declare _id int default 0;
	declare done int default 0;
	declare region_cursor cursor for select id from region where pid=fid;
	declare continue handler for sqlstate '02000' set done=1;
	SET m=_lft;
	set @@max_sp_recursion_depth =2000;
	open region_cursor;
	REPEAT
		FETCH region_cursor INTO _id;
		IF NOT done THEN
		  call region_pro(m+1,_id,m);
		  set m=m+1;
		END IF;
	UNTIL done END REPEAT;
	update region set lft=_lft,rgt=m+1 where id=fid;
    END$$

DELIMITER ;