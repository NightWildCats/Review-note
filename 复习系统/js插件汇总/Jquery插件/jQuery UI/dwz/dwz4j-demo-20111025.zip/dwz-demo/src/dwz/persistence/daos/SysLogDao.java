package dwz.persistence.daos;

import dwz.persistence.beans.SysLog;
import dwz.dal.BaseDao;

public interface SysLogDao extends BaseDao<SysLog, String> {

}
