package dwz.framework.constants.user;

public enum Title {
	Mr, Mrs, Miss, Ms, Dr, Prof;

	public String getName(){
		return this.toString();
	}
}
