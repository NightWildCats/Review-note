package dwz.framework.http.session.mdb.mysqldb.schedule;

public class SessionException extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = -287101386532361208L;

	public SessionException() {
		// TODO Auto-generated constructor stub
	}

	public SessionException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public SessionException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public SessionException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

}
