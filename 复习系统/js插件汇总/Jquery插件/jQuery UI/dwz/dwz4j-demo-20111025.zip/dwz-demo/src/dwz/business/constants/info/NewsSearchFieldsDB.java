package dwz.business.constants.info;

public enum NewsSearchFieldsDB {
	TYPE, STATUS, COMPANY_ID, KEYWORDS
}
