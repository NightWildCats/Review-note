package dwz.constants;

public enum MailTemplateKey {
	defaultVm, registerConfirm, emailToFriend, forgetPassword
}
