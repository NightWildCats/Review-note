package dwz.framework.core.business;

public interface BusinessObjectManager {


}
