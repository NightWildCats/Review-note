package dwz.business.constants.content;

public enum FileSearchFields {
	USER_ID, NAME, FILE_TYPE, keywords, FOLDER, ROLE
}
