package dwz.framework.syslog;

public enum SystemLogLevel {
	ERROR, WARN, INFO;
	
	
}
