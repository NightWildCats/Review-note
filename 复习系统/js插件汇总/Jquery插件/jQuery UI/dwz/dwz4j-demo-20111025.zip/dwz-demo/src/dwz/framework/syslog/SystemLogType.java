package dwz.framework.syslog;

public enum SystemLogType {
	LODGE_REPORT, LODGE_EA
}
