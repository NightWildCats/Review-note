package dwz.constants;

public enum BeanManagerKey {
	sessionManager,mailManager,userManager,roleManager,setupManager,systemLogManager,
	newsManager,contentManager,websiteManager,categoryManager
}
