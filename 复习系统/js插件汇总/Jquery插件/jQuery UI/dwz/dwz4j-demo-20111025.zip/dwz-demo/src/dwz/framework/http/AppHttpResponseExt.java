package dwz.framework.http;

import javax.servlet.http.HttpServletResponse;

public interface AppHttpResponseExt extends HttpServletResponse {

}
