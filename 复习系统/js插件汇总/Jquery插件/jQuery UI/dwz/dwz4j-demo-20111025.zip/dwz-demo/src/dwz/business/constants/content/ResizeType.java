package dwz.business.constants.content;

public enum ResizeType {
	S, M
}
