package dwz.dal;


class DaoConstant {

	public static final String PAGE_BREAK_SUFFIX = "PageBreak";

	public static final String FIND_PREFIX = "find";

	public static final String DELETE_ALL_PREFIX = "deleteAll";

	public static final String UPDATE_ALL_PREFIX = "updateAll";
	
	public static final int INSERT_SIZE = 50;
}
