package dwz.framework.constants.user;

public enum UserStatus {
	ACTIVE, INACTIVE, DELETED
}
