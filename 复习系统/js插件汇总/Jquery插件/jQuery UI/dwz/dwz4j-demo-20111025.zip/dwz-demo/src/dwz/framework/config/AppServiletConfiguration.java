package dwz.framework.config;

import java.io.Serializable;

public interface AppServiletConfiguration extends Serializable {

	public String getAppServiletName();

	public String getImplementClass();

}
