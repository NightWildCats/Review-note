package dwz.framework.constants.user;

public enum UserSearchFields {
	KEYWORDS,USER_NAME,USER_TYPE,FIRST_NAME,LAST_NAME,EMAIL,PHONE,STATUS,TITLE,POSTCODE,ROLE;	
}

