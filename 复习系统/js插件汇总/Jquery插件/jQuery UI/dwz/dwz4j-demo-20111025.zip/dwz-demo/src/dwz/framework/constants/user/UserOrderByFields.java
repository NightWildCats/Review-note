package dwz.framework.constants.user;

public enum UserOrderByFields {
	USER_NAME,USER_NAME_DESC,EMAIL,EMAIL_DESC,
	FIRST_NAME,FIRST_NAME_DESC,INSERT_DATE,INSERT_DATE_DESC,
	STATUS, STATUS_DESC;
}
