package dwz.persistence.daos;

import dwz.persistence.beans.WebWebsite;
import dwz.dal.BaseDao;

public interface WebsiteDao extends BaseDao<WebWebsite, Integer> {

}
