package dwz.framework.http;

import javax.servlet.http.HttpServletRequest;

public interface AppHttpRequestExt extends HttpServletRequest {

//	public static final String ACCOUNT_KEY = "COREZON_ACCOUNT";

//	public static final String USER_KEY = "COREZON_USER";

//	public static final String STORE_KEY = "COREZON_STORE";

//	public Account getAccount();

//	public User getUser();

}
