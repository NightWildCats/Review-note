package dwz.constants;

public enum BeanDaoKey {

	sysUserDao, sysSessionDao, setPreferenceDao, 
	webSiteDao, webPageDao, 
	conFileDao, conFolderDao,
	infNewsDao

}
