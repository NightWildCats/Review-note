/**
 * 
 */
package dwz.framework.log.services;

import dwz.framework.sys.business.BusinessObjectServiceMgr;

/**
 * @author peng.shi
 *
 */
public interface LogServiceMgr extends BusinessObjectServiceMgr
{
	public static final String SERVICE_NAME = "logServiceMgr";
}
