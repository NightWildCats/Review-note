package dwz.persistence.mapper;

import dwz.dal.BaseMapper;
import dwz.persistence.beans.ResBook;
import org.springframework.stereotype.Repository;

@Repository
public interface ResBookMapper extends BaseMapper<ResBook,Integer>{
	

}
