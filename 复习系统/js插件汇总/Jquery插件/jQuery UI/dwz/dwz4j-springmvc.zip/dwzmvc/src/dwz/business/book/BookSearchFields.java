package dwz.business.book;

public enum BookSearchFields {

}
