package dwz.web;

//import javax.inject.Inject;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import dwz.business.book.Book;
import dwz.business.book.BookServiceMgr;
import dwz.business.book.Chapter;
import dwz.business.book.ChapterConditionVO;

@Controller
public class IndexController extends BaseController{

	// @Inject
	// private User user;

	@Autowired
	private BookServiceMgr bookMgr;
	
	@RequestMapping("")
	public String index() {
		return "redirect:/chapters";
	}

	@RequestMapping("/books")
	public String books(Model model) {System.out.println(getMessage("ui.title"));
		List<Book> bookList = bookMgr.searchBook(null, null, 0, 100);
		model.addAttribute(bookList);
		return "/books";
	}
	
	@RequestMapping("/chapters")
	public String chapters(ChapterConditionVO vo, Model model) {
		List<Chapter> chapters = bookMgr.searchChapters(vo);
	
		model.addAttribute("chapters", chapters);
		
		return "/chapters";
	}
	
	@RequestMapping("/chapter/{chapterId}")
	public String chapter(@PathVariable("chapterId") int chapterId, Model model) {

		Chapter chapter = bookMgr.getChapter(chapterId);
		Book book = bookMgr.getBook(chapter.getBookId());
		model.addAttribute(chapter);
		model.addAttribute(book);

		return "/chapter";
	}
}