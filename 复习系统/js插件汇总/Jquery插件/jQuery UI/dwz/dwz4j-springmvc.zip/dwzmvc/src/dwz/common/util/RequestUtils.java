package dwz.common.util;

/**
 * <strong>RequestUtils</strong><br>
 * <br> 
 * <strong>Create on : 2012-1-5<br></strong>
 * <p>
 * <strong>Copyright (C) Ecointel Software Co.,Ltd.<br></strong>
 * <p>
 * @author peng.shi peng.shi@ecointel.com.cn<br>
 * @version <strong>Ecointel v1.0.0</strong><br>
 */
public class RequestUtils
{
	
}
