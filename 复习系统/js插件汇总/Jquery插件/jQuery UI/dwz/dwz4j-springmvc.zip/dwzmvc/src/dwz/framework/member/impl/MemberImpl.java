/**
 * 
 */
package dwz.framework.member.impl;

import java.util.Date;

import dwz.framework.enums.YesNo;
import dwz.framework.member.Member;
import dwz.framework.sys.business.AbstractBusinessObject;

/**
 * @author peng.shi
 *
 */
public class MemberImpl extends AbstractBusinessObject implements Member
{
	private static final long serialVersionUID = -2878481080284121420L;

	/* (non-Javadoc)
	 * @see dwz.framework.member.Member#getConfirmed()
	 */
	@Override
	public YesNo getConfirmed()
	{
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see dwz.framework.member.Member#getEmail()
	 */
	@Override
	public String getEmail()
	{
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see dwz.framework.member.Member#getFirstName()
	 */
	@Override
	public String getFirstName()
	{
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see dwz.framework.member.Member#getId()
	 */
	@Override
	public Long getId()
	{
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see dwz.framework.member.Member#getInsertTime()
	 */
	@Override
	public Date getInsertTime()
	{
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see dwz.framework.member.Member#getPassword()
	 */
	@Override
	public String getPassword()
	{
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see dwz.framework.member.Member#getSurName()
	 */
	@Override
	public String getSurName()
	{
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see dwz.framework.member.Member#getUpdateTime()
	 */
	@Override
	public Date getUpdateTime()
	{
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see dwz.framework.member.Member#getUsername()
	 */
	@Override
	public String getUsername()
	{
		// TODO Auto-generated method stub
		return null;
	}

	/* (non-Javadoc)
	 * @see dwz.framework.member.Member#setEmail(java.lang.String)
	 */
	@Override
	public void setEmail(String email)
	{
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see dwz.framework.member.Member#setFirstName(java.lang.String)
	 */
	@Override
	public void setFirstName(String firstName)
	{
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see dwz.framework.member.Member#setPassword(java.lang.String)
	 */
	@Override
	public void setPassword(String pwd)
	{
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see dwz.framework.member.Member#setSurName(java.lang.String)
	 */
	@Override
	public void setSurName(String surName)
	{
		// TODO Auto-generated method stub

	}

}
