/**
 * 
 */
package dwz.framework.member.persistence.object;

import dwz.dal.object.AbstractDO;

/**
 * @author peng.shi
 *
 */
public class UsrMember extends AbstractDO
{
	private static final long serialVersionUID = -8579202807583348459L;
}
