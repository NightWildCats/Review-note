package dwz.business.task;

import dwz.business.book.BookServiceMgr;
import dwz.framework.sys.business.BusinessFactory;


public class Pdf2jsonTask implements Runnable  {

	
	public void run() {
		System.out.println("Start Pdf2jsonTask...");
		BookServiceMgr bookMgr = BusinessFactory.getInstance().getService("bookServiceMgr");
		bookMgr.initChaptersContent();
	}	
}
