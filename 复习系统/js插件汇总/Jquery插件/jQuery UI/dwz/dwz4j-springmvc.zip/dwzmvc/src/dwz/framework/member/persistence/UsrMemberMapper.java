/**
 * 
 */
package dwz.framework.member.persistence;

import dwz.dal.BaseMapper;
import dwz.framework.member.persistence.object.UsrMember;

/**
 * @author peng.shi
 *
 */
public interface UsrMemberMapper extends BaseMapper<UsrMember, Long>
{
	
}
