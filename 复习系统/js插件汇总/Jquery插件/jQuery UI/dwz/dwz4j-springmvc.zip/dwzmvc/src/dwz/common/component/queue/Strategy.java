package dwz.common.component.queue;

/**
 * 策略抽象对象
 * @author liqiang
 */
public abstract class Strategy implements PutMethod, GetMethod {

}
