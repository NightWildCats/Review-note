[jQuery Tools](http://flowplayer.org/tools/) - The Missing UI library for the Web
================================

jQuery Tools is a collection of the most important user-interface components for modern websites. Used by large sites all over the world.

##Contributing

Please issue pull requests to the [dev branch](https://github.com/jquerytools/jquerytools/tree/dev).  

This is where active development takes place, we then merge changes into master for releases. That will become v1.2.6. 
Most of the development goes to 2.0 which is currently a private repository.

