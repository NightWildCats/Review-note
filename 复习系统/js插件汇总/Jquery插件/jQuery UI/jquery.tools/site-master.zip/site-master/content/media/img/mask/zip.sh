zip expose.zip mask*
