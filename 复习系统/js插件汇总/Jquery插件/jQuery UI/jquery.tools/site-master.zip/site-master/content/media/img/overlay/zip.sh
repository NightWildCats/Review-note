zip overlay.zip *.png
