zip tabs.zip *.jpg *.png
