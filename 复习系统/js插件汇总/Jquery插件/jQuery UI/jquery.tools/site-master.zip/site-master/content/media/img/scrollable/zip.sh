zip scrollable.zip arrow/*.png *.jpg
